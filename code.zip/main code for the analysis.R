rm(list = ls())
#code for ssGSEA:Estimation of infiltrating immune cells in the TME
load("tcga_fpkm.Rdata")
load("cellMarker_ssGSEA.Rdata")
expr <- as.matrix(tcga_fpkm)
library(GSVA)
gsva_data <- gsva(expr,cellMarker, method = "ssgsea")
GSVAdata=as.data.frame(gsva_data)



#for Unsupervised clustering for infiltrating immune cells
rm(list = ls())
load("28immuData.Rdata")
input=scale(immuData)
library(ConsensusClusterPlus)
input=scale(input)  
input=as.matrix(t(input))

results <-  ConsensusClusterPlus(input,
                                 maxK = 5, 
                                 reps = 5000, 
                                 pItem = 0.8, 
                                 pFeature = 1,
                                 clusterAlg="km",
                                 distance="euclidean",
                                 seed = 0415, 
                                 title="TCGA", 
                                 innerLinkage="complete",
                                 plot="pdf")

icl = calcICL(results,
              title="TCGA",
              plot="pdf")



#code for heatmap(Fig. 1A)
rm(list = ls())
load("data_heatmap1.Rdata")
#
annColors <- list()
annColors[["Age"]] <- colorRampPalette(c("#F7D202", "#96862A"))(64)
annColors[["Gender"]] <- c("male"="#79B789","female"="#B5262A")
annColors[["Cytogenetics Risk"]] <- c("Favorable"="#53B1E7",
                                      "Intermediate"="#C78157",
                                      "Poor"="#A54D48",
                                      "NA"="#CBBEC1")
annColors[["FAB"]] <- c("M0"="#223D6C","M1"="#D20A13","M2"="#FFD121",
                        "M3"="#088247","M4"="#11AA4D","M5"="#58CDD9",
                        "M6"="#7A142C","M7"="#5D90BA")
annColors[["TMEsubtype"]] <- c("TMEsubtype A"="#008ECB","TMEsubtype B"="#EA921D")
annColors

library(pheatmap)
pheatmap(immucell,
         scale = "row",
         color = colorRampPalette(c("#343493", "white", "#C24A45"))(64),
         annotation_col = meta,
         cluster_cols=F,
         cluster_rows=T,  
         annotation_colors = annColors,
         show_rownames = T, show_colnames = F,
         treeheight_row=0)



#code for Fig.1B
rm(list = ls())
load("data_survival.Rdata")
#
library(survival)
library(survminer)

meta$TMEsubtype=factor(meta$TMEsubtype,levels = c("TMEsubtypeA","TMEsubtypeB"),ordered = F)
sfit <- survfit(Surv(time, event) ~ TMEsubtype,
                data = meta)
ggsurvplot(fit=sfit,
           title="TCGA LAML Patients",
           legend.title = "TMEsubtype",
           legend.labs = c("TMEsubtype A","TMEsubtype B"),
           legend = c(0.8,0.8),
           pval = T, 
           pval.method = TRUE,
           #conf.int = TRUE,
           risk.table = TRUE, 
           #risk.table.col = "strata", 
           risk.table.y.text = F,
           #linetype = "strata", 
           surv.median.line = "hv", 
           xlab = "Time in months", 
           #xlim = c(0,10), 
           #break.time.by = 2, 
           linetype=1,
           size = 1, 
           #ggtheme = theme_bw(), 
           palette = c("orange","blue")
) 



#code for Fig. 1C
load("data_box.Rdata")
library(dplyr)
library(tidyr)
dd <- dd %>% 
  pivot_longer(cols=2:29,
               names_to= "celltype",
               values_to = "NES")

library(ggplot2)
library(ggpubr)

ggplot(data =dd, aes(x = celltype, y = NES))+
  geom_boxplot(aes(fill = TMEsubtype),position = position_dodge(1),width=.3,outlier.shape = NA)+
  geom_violin(aes(colour = TMEsubtype),position = position_dodge(1),scale = "width",fill=NA)+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1,vjust = 1, colour = "black"))+
  stat_compare_means(aes(group=TMEsubtype), label = "p.signif")+
  ylab("Abundance of immune cells")+xlab(NULL)+ #x,y轴的标题
  theme(legend.position = "top")



#code for Fig.1D/E
rm(list = ls())
load(file = "data_vio.Rdata")
library(ggpubr)
library(ggplot2)
ggviolin(data, x="TMEsubtype", y="HAVCR2", fill = "TMEsubtype", 
         xlab="", ylab="Tim-3 Expression",
         palette=c("#0066FF","#FF0000"),
         legend.title="TMEsubtype",
         add = "boxplot", add.params = list(fill="white"))+ 
  stat_compare_means(label.x = 1.3,label.y.npc = "top")


ggviolin(data, x="TMEsubtype", y="CTLA4", fill = "TMEsubtype", 
         xlab="", ylab="CTLA4 Expression",
         palette=c("#0066FF","#FF0000"),
         legend.title="TMEsubtype",
         add = "boxplot", add.params = list(fill="white"))+ 
  stat_compare_means(label.x = 1.3,label.y.npc = "top")


#code for Fig3 A
load("data_snakey.Rdata")
library(ggalluvial)
mycol <- rep(c("#223D6C","#D20A13","#FFD121","#088247","#11AA4D","#58CDD9","#7A142C","#5D90BA","#029149","#431A3D","#91612D","#6E568C","#E0367A","#D8D155","#64495D","#7CC767"),2)


df=data
UCB_lodes <- to_lodes_form(df[,1:ncol(df)],
                           axes = 1:ncol(df),
                           id = "Cohort")
dim(UCB_lodes)

ggplot(UCB_lodes,
       aes(x=x,stratum = stratum, alluvium = Cohort,
           fill = stratum,label = stratum)) +
  scale_x_discrete(
    expand = c(0,0)
  ) + 
  geom_flow(width = 1/8) + 
  geom_stratum(alpha = .9,width = 1/8) + 
  geom_text(stat = "stratum", size = 2.5,color="black") + 
  
  scale_fill_manual(values = mycol) +
  
  xlab("") + ylab("") +
  theme_bw() + 
  theme(panel.grid =element_blank()) + 
  theme(panel.border = element_blank()) + 
  theme(axis.line = element_blank(),axis.ticks = element_blank(),axis.text.y =element_blank()) + 
  ggtitle("")+
  guides(fill = "none") 



##
rm(list = ls())
load(file = "data_box4.Rdata")
dd=data
library(dplyr)
library(tidyr)
dd <- dd %>% 
  pivot_longer(cols=2:5,
               names_to= "gene",
               values_to = "expression")
library(ggplot2)
library(ggpubr)
### 
ggplot(data =dd, aes(x = gene, y = expression))+
  geom_boxplot(aes(fill =`TME score`),outlier.shape = NA)+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1,vjust = 1, colour = "black"))+
  stat_compare_means(aes(group=`TME score`), label = "p.signif")+
  ylab("gene expression (log2(FPKM+1))")+xlab(NULL)+   
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  theme(legend.position = "top")





#code for GSEA (Fig.2C/D)
rm(list = ls())
library(clusterProfiler)
library(ggplot2)
load("diff.Rdata")

allDiff=alldiff

gene <- rownames(allDiff)

## 
gene = bitr(gene, fromType="SYMBOL", toType="ENTREZID", OrgDb="org.Hs.eg.db")
## 
gene <- dplyr::distinct(gene,SYMBOL,.keep_all=TRUE)
gene_df <- data.frame(logFC=allDiff$log2FoldChange,SYMBOL = rownames(allDiff))
gene_df <- merge(gene_df,gene,by="SYMBOL")

##
geneList <- gene_df$logFC

names(geneList) = gene_df$ENTREZID

geneList = sort(geneList, decreasing = TRUE)


hallmarks <- read.gmt("h.all.v7.5.1.entrez.gmt")
hallmarks$term=substring(hallmarks$term,10)
y <- GSEA(geneList,TERM2GENE =hallmarks)

library(enrichplot)
gseaplot2(y, geneSetID = c(2,10,8,4,1))



#code for Fig3
rm(list = ls())
load("data_drugsensi.Rdata")
library(ggplot2)
library(ggpubr)
ggplot(data =data, aes(x = `TME score`, y = Paclitaxel))+
  geom_boxplot(aes(fill = `TME score`),outlier.shape = NA)+
  theme_bw()+
  theme(axis.text.x = element_text(angle = 0, hjust = 1,vjust = 1, colour = "black"))+
  #geom_jitter(width = 0.2)+
  stat_compare_means(aes(group=`TME score`),label.x = 1.4)+
  ylab(paste0("Paclitaxel"," ","sensitivity (IC50)"))+xlab(NULL)+   
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  #stat_compare_means(comparisons=my_comparisons,label.y = c(2, 2.5, 2.8))+ 
  theme(legend.position = "top")




#code for Fig3
load(file = "data_TIDE.Rdata")
library(ggpubr)
library(ggplot2)
ggviolin(TIDE, x="TME score", y="Exclusion", fill = "TME score", 
         xlab="TCGA LAML", ylab="Exclusion",
         palette=c("#0066FF","#FF0000"),
         legend.title="TME score",
         add = "boxplot", add.params = list(fill="white"))+ 
  stat_compare_means(label.x = 1.3,label.y.npc = "top")
